ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1119478.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 44966332, 44966324, 44966322 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: true,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
